// handle_mail.js

const mailInfo = {
    funideaEmailIfo: {
        user: '', // 본인 메일 아이디
        pass: ''  // 본인 메일 비밀번호
        // 본 프로젝트의 경우 네이버로 설정
    }
}; 

module.exports = mailInfo;
